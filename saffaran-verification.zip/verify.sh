#!/bin/bash
set -e

echo "=== 1. Terraform Output Verification ==="
cd ../saffaran-aviation-automation/terraform || exit 1
terraform output

echo "=== 2. EKS Connection ==="
aws eks update-kubeconfig --region us-east-1 --name saffaran-eks-cluster
kubectl get nodes

echo "=== 3. Pods in saffaran Namespace ==="
kubectl get pods -n saffaran

echo "=== 4. Service Check ==="
kubectl get svc -n saffaran

echo "=== 5. API Health Check ==="
kubectl port-forward -n saffaran svc/saffaran-api 8080:80 &
PF_PID=$!
sleep 5
curl -s http://127.0.0.1:8080/health
kill $PF_PID

echo "=== 6. Send Sample Report ==="
curl -X POST http://127.0.0.1:8080/report      -H "Content-Type: application/json"      -d @../saffaran-aviation-automation/sample_data/turbine_sample.json

echo "=== 7. Check S3 Upload ==="
aws s3 ls $(terraform output -raw s3_bucket)/reports/ --recursive

echo "=== 8. Redis Cache Check (requires redis-cli installed) ==="
REDIS_ENDPOINT=$(terraform output -raw redis_endpoint)
redis-cli -h $REDIS_ENDPOINT HGETALL reports || echo "Redis check skipped."

echo "=== 9. CloudWatch Logs Check ==="
aws logs describe-log-groups --query 'logGroups[?logGroupName==`/aws/saffaran/app`]'

echo "=== Verification Complete ==="
